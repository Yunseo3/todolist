package com.example.thisisspring.Service;

import com.example.thisisspring.domain.CoffeeBean;
import com.example.thisisspring.dto.CoffeeBeanDto;
import com.example.thisisspring.repository.CoffeeBeanRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CoffeeBeanService {

    private final CoffeeBeanRepository coffeeBeanRepository;

    // 스프링 프레임워크 4.3 이후부터는 단일 생성자 크래스에 @autowired 생략 가능합니다!
    public CoffeeBeanService(CoffeeBeanRepository coffeeBeanRepository) {
        this.coffeeBeanRepository = coffeeBeanRepository;
    }

    public void saveTenCoffeeBeansEfficient() {
        List<CoffeeBean> coffeeBeans = new ArrayList<>();

        for (int i = 1; i <= 10; i++) {
            String coffeeName = "커피 이름" + i;
            int quantity = 100;
            CoffeeBean coffeeBean = new CoffeeBean(coffeeName, quantity);
            coffeeBeans.add(coffeeBean);
        }

        coffeeBeanRepository.saveAll(coffeeBeans);
    }

    public List<CoffeeBeanDto> getAllCoffeeBeansDto() {
        List<CoffeeBean> coffeeBeans = coffeeBeanRepository.findAll();

        // CoffeeBean을 CoffeeBeanDto로 변환하여 리스트로 반환
        return coffeeBeans.stream()
                .map(coffeeBean -> new CoffeeBeanDto(coffeeBean.getId(), coffeeBean.getName(), coffeeBean.getQuantity()))
                .toList();
    }

}




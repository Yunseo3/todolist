package com.example.thisisspring.repository;

import com.example.thisisspring.domain.Camera;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
public interface CameraRepository extends JpaRepository<Camera, Long> {
    Optional<Camera> findByName(String name);
}
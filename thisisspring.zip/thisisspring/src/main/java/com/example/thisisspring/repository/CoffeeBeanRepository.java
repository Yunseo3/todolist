package com.example.thisisspring.repository;

import com.example.thisisspring.domain.CoffeeBean;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CoffeeBeanRepository extends JpaRepository<CoffeeBean, Long> {

}
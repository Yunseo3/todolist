package com.example.thisisspring.controller;

import com.example.thisisspring.domain.CoffeeBean;
import com.example.thisisspring.dto.CoffeeBeanDto;
import com.example.thisisspring.Service.CoffeeBeanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/coffee")
public class CoffeeBeanController {

    private final CoffeeBeanService coffeeBeanService;

    // 단일 생성자는 @Autowired를 생략할 수 있으나, 한동안은 명시적으로 표현하도록 하겠습니다.
    @Autowired
    public CoffeeBeanController(CoffeeBeanService coffeeBeanService) {
        this.coffeeBeanService = coffeeBeanService;
    }

    @PostMapping("/create")
    public String createCafeBeans() {
        coffeeBeanService.saveTenCoffeeBeansEfficient();
        return "10개의 카페 데이터가 생성되었습니다.";
    }
    @GetMapping("/list")
    public ResponseEntity<List<CoffeeBeanDto>> getAllCoffeeBeans() {
        List<CoffeeBeanDto> coffeeBeansDto = coffeeBeanService.getAllCoffeeBeansDto();

        if (coffeeBeansDto.isEmpty()) {
            // 만약 데이터가 없을 경우
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            // 데이터가 있을 경우
            return new ResponseEntity<>(coffeeBeansDto, HttpStatus.OK);
        }
    }
}
package com.example.thisisspring.Service;

import com.example.thisisspring.domain.Camera;
import com.example.thisisspring.dto.CameraDto;
import com.example.thisisspring.repository.CameraRepository;
import org.springframework.stereotype.Service;

import jakarta.persistence.EntityNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CameraService {

    private final CameraRepository cameraRepository;

    // 스프링 프레임워크 4.3 이후부터는 단일 생성자 크래스에 @autowired 생략 가능합니다!
    public CameraService(CameraRepository cameraRepository) {
        this.cameraRepository = cameraRepository;
    }

    public void saveTenCameraEfficient() {
        List<Camera> cameras = new ArrayList<>();

        for (int i = 1; i <= 10; i++) {
            String cameraName = "카메라 이름" + i;
            int count= 100;
            int price = 1000;
            Camera camera = new Camera(cameraName, count, price);
            cameras.add(camera);
        }

        cameraRepository.saveAll(cameras);
    }

    public List<CameraDto> getAllCameraDto() {
        List<Camera> cameras = cameraRepository.findAll();

        // CoffeeBean을 CoffeeBeanDto로 변환하여 리스트로 반환
        return cameras.stream()
                .map(camera -> new CameraDto(camera.getId(), camera.getName(), camera.getCount(), camera.getPrice()))
                .collect(Collectors.toList());
    }

    public void updateCameraQuantity(String name, int CountToAdd, int PriceToAdd) {
        Camera camera = cameraRepository.findByName(name)
                .orElseThrow(() -> new EntityNotFoundException("해당 이름의 커피 데이터를 찾을 수 없습니다."));

        camera.setCount(camera.getCount() + CountToAdd);
        cameraRepository.save(camera);

    }
}
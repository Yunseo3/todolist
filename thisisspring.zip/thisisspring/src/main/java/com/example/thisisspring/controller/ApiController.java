package com.example.thisisspring.controller;

/*
import com.example.thisisspring.dto.MemberDto;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/api")
public class ApiController {

/*
    @GetMapping(value = "/request")
    public String getRequestParam(MemberDto memberDto) {
        return memberDto.toString();
    }
*/
/*
    @PutMapping(value = "/member")
    public String postMember(@RequestBody Map<String, Object> putData) {
        StringBuilder sb = new StringBuilder();

        putData.forEach((key, value) -> sb.append(key + " : " + value + "\n"));
        return sb.toString();

*/
/*
    @PostMapping(value = "/member")
    public String postMemberDto(@RequestBody MemberDto memberDto) {
        return memberDto.toString();

    }
}
/*
    @PutMapping(value = "/member1")
    public String postMemberDto1(@RequestBody MemberDto memberDto) {
        return memberDto.toString();
    }

    @PutMapping(value = "/member2")
    public MemberDto postMemberDto2(@RequestBody MemberDto memberDto) {
        return memberDto;
    }
*/

    /*
    @PutMapping(value = "/member")
    public ResponseEntity<MemberDto> postMemberDto(@RequestBody MemberDto memberDto) {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(memberDto);
}
*/
/*
    @GetMapping(value = "/request")
    public String getRequestParam(MemberDto memberDto){
        return memberDto.toString();
    }
/*
    @PostMapping(value = "/member")
    public String postMemberDto(@RequestBody MemberDto memberDto) {
        return memberDto.toString();

    }
*/
    /*
    @PutMapping(value = "/member")
    public  ResponseEntity<MemberDto> postMemberDto(@RequestBody MemberDto memberDto) {
        return ResponseEntity
                .status(HttpStatus.OK)
                .body(memberDto);
    }

    @ApiOperation(value = "GET 메서드 예제", notes = "@RequestParam을 활용한 GET Method")
    @GetMapping(value = "/request")
    public String getRequestParam(
            @ApiParam(value = "이름", required = true) @RequestParam String name,
            @ApiParam(value = "이메일", required = true) @RequestParam String email,
            @ApiParam(value = "회사", required = true) @RequestParam String organization) {
        return name + " " + email + " " + organization;
    }
}
*/
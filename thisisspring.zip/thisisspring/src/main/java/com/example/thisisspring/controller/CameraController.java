package com.example.thisisspring.controller;

import com.example.thisisspring.domain.Camera;
import com.example.thisisspring.dto.CameraDto;
import com.example.thisisspring.repository.CameraRepository;
import com.example.thisisspring.Service.CameraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.web.bind.annotation.*;

import jakarta.persistence.EntityNotFoundException;
import java.util.List;

@RestController
@RequestMapping("/camera")
public class CameraController {

    private final CameraService cameraService;
    private final CameraRepository cameraRepository;

    // 단일 생성자는 @Autowired를 생략할 수 있으나, 한동안은 명시적으로 표현하도록 하겠습니다.
    @Autowired
    public CameraController(CameraService cameraService, CameraRepository cameraRepository) {
        this.cameraService = cameraService;
        this.cameraRepository = cameraRepository;
    }

    @PostMapping("/create")
    public String createCamera() {
        cameraService.saveTenCameraEfficient();
        return "10개의 카메라 데이터가 생성되었습니다.";
    }

    @GetMapping("/list")
    public ResponseEntity<List<CameraDto>> getAllCameras() {
        List<CameraDto> camerasDto = cameraService.getAllCameraDto();

        if (camerasDto.isEmpty()) {
            // 만약 데이터가 없을 경우
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } else {
            // 데이터가 있을 경우
            return new ResponseEntity<>(camerasDto, HttpStatus.OK);
        }
    }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String> deleteCameraById(@PathVariable Long id) {
        if (cameraRepository.existsById(id)) { // 해당 id 값의 데이터가 있는 경우 처리
            cameraRepository.deleteById(id);
            return new ResponseEntity<>("카메라 데이터가 삭제되었습니다.", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("해당 ID의 카메라 데이터를 찾을 수 없습니다.", HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/update")
    public ResponseEntity<String> updateCameraQuantity(@RequestBody CameraDto cameraDto) {
        try {
            cameraService.updateCameraQuantity(cameraDto.getName(), cameraDto.getCount(), cameraDto.getPrice());
            return ResponseEntity.ok("카메라 데이터의 재고가 업데이트 되었습니다.");
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("카메라 데이터 재고 업데이트 중에 오류가 발생했습니다.");
        }
    }
}